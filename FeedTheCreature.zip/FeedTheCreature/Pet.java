
public class Pet {
	int x;
	int y;
	EZImage picture;
	
	Pet(){
		x = 400;
		y = 500;
		picture = EZ.addImage("pet.png", x, y);		
		}
	}		

