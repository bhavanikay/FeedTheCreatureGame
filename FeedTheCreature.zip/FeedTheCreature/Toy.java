
public class Toy {

}
