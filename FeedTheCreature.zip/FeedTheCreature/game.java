import java.awt.Color;

public class game {
	
	public static void main(String[] args) {
		EZ.initialize(800, 800);
		EZImage game_over = EZ.addImage("gameover.png", 400, 400);
		game_over.pushToBack();
		EZImage background = EZ.addImage("background.png", 400, 400);
		EZText age;
		EZSound eat = EZ.addSound("eat.wav");
		EZSound clean = EZ.addSound("fart.wav");
		EZSound play = EZ.addSound("play.wav");
		Pet pet = new Pet();
		Toy toy = new Toy();
		
		//Set age variable with text along with time
		long time = System.currentTimeMillis();
		int year = 0;
		Color pink = new Color(255, 175, 175);
		age = EZ.addText(700, 50, "Age: " + year, pink, 50);
		}
		
	
		
	}
